package br.com.palpitepro;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class HistoricalCsv {
    public static class Row {
        public String market; public double probability; public double outcome;
        Row(String m,double p,double o){market=m;probability=p;outcome=o;}
    }
    // CSV: market,probability,outcome
    public static List<Row> read(InputStream in) throws Exception {
        List<Row> out=new ArrayList<>();
        BufferedReader r=new BufferedReader(new InputStreamReader(in));
        String s; boolean first=true;
        while((s=r.readLine())!=null){
            if(first){first=false; if(s.toLowerCase().contains("market")) continue;}
            String[] x=s.split(",");
            if(x.length<3) continue;
            try{out.add(new Row(x[0].trim(),Double.parseDouble(x[1].trim()),Double.parseDouble(x[2].trim()));}
            catch(Exception ignored){}
        }
        r.close(); return out;
    }
}