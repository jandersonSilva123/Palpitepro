    void showTips(){
        base("Palpites","Seleção de mercados com maior probabilidade estimada");
        LinearLayout c=card();
        c.addView(label("🔥 DESTAQUES"));
        addMarket(c,"Flamengo x Palmeiras • Mais de 1,5 gols","70%","ALTA",green);
        addMarket(c,"Real Madrid x Man. City • Ambas marcam","55%","MÉDIA",Color.rgb(255,201,74));
        addMarket(c,"Mercado de escanteios • +8,5","60%","ALTA",green);
        addMarket(c,"Mercado de escanteios • +9,5","52%","MÉDIA",Color.rgb(255,201,74));
        content.addView(c,margin());

        LinearLayout how=card();
        how.addView(label("COMO O MODELO FUNCIONA"));
        how.addView(tv("• Usa médias de escanteios por equipe e temporada quando disponíveis.",14,white));
        how.addView(tv("• Calcula linhas de escanteios com distribuição de Poisson.",14,white));
        how.addView(tv("• Separa probabilidade do modelo de odds de mercado.",14,white));
        how.addView(tv("• O backtesting deve ser feito antes de usar o modelo em produção.",14,white));
        content.addView(how,margin());
    }

    void showBacktest(){
        base("Backtesting","Desempenho histórico do modelo");
        LinearLayout c=card();
        c.addView(label("MÉTRICAS"));
        android.database.Cursor cur=predictionDb.settled();
        BacktestMetrics.Report r=BacktestMetrics.from(cur);
        cur.close();
        c.addView(tv("Amostras: "+r.n,16,white));
        c.addView(tv(String.format(java.util.Locale.US,"Brier Score: %.4f",r.brier),16,green));
        c.addView(tv(String.format(java.util.Locale.US,"Log Loss: %.4f",r.logLoss),16,green));
        c.addView(tv(String.format(java.util.Locale.US,"Acurácia (limiar 50%%): %.1f%%",r.accuracy*100),16,white));
        content.addView(c,margin());

        LinearLayout d=card();
        d.addView(label("COMO INTERPRETAR"));
        d.addView(tv("Brier e Log Loss medem a qualidade das probabilidades; menor é melhor. Acurácia depende do limiar e não substitui calibração.",13,muted));
        d.addView(tv("Antes de publicar o modelo, separe treino, validação e teste por data para evitar vazamento de informação.",13,muted));
        content.addView(d,margin());
    }

    void showStats(){
        base("Estatísticas","Indicadores de desempenho");
        LinearLayout c=card();
        c.addView(label("BRASILEIRÃO"));
        c.addView(tv("Média de gols",14,muted));
        c.addView(tv("2,48 gols / jogo",24,green));
        c.addView(tv("Mais de 2,5: 52%",14,white));
        c.addView(tv("Escanteios: 10,1 / jogo",14,white));
        c.addView(tv("Cartões: 4,7 / jogo",14,white));
        content.addView(c,margin());

        LinearLayout d=card();
        d.addView(label("FILTROS"));
        String[] chips={"Hoje","Mais de 1,5","Ambas marcam","Escanteios","Cartões","Odds"};
        LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL);
        for(String s:chips){ TextView x=tv(s,11,white); x.setGravity(Gravity.CENTER); x.setBackground(rounded(surface2,24)); x.setPadding(14,8,14,8); r.addView(x,new LinearLayout.LayoutParams(-2,38)); }
        d.addView(r);
        content.addView(d,margin());
    }

    void showProfile(){
        base("Meu perfil","PalpitePro");
        LinearLayout c=card();
        TextView name=tv("Janderson Silva",20,white); name.setTypeface(null,1);
        c.addView(name);
        c.addView(tv("Membro desde 2026",13,muted));
        content.addView(c,margin());

        TextView premium=button("💎  Conhecer o Premium");
        content.addView(premium,margin());

        LinearLayout menu=card();
        String[] items={"Meus palpites","Meus favoritos","Alertas","Backtesting do modelo","Histórico de resultados","Configurações","Ajuda e suporte"};
        for(String s:items){
            TextView x=tv("›  "+s,15,white);
            x.setPadding(0,12,0,12);
            if(s.startsWith("Backtesting")) x.setOnClickListener(v -> showBacktest());
            menu.addView(x);
        }
        content.addView(menu,margin());
    }
}