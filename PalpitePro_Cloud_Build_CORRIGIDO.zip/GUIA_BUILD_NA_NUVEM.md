# PalpitePro — Build na Nuvem pelo celular

Este projeto foi preparado para gerar o APK usando GitHub Actions, sem Android Studio no celular.

## Passo a passo

1. Crie uma conta no GitHub pelo navegador do celular.
2. Crie um repositório novo, por exemplo `PalpitePro`.
3. Envie todos os arquivos desta pasta para o repositório.
4. Abra a aba **Actions**.
5. Selecione **Build PalpitePro APK**.
6. Toque em **Run workflow**.
7. Aguarde o processo terminar.
8. Abra a execução concluída e procure **Artifacts**.
9. Baixe `PalpitePro-debug-apk.zip`.
10. Extraia o ZIP e instale o APK no Android.

O workflow foi configurado para usar Java 17, Android API 36 e gerar `assembleDebug`.

Observação: esta é uma versão de teste/debug. Para publicação em loja, é necessário configurar uma chave de assinatura de release.
