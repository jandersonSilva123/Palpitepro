# PalpitePro

MVP Android nativo de um aplicativo de análise esportiva e palpites.

## O que já está implementado

- Tela inicial com jogos
- Probabilidades 1X2
- Tela de análise da partida
- Mercados: gols, ambas marcam, escanteios e cartões
- Nível de confiança
- Tela de palpites
- Tela de estatísticas
- Perfil
- Navegação inferior
- Interface escura inspirada no protótipo criado

## Importante

Esta versão agora possui integração opcional com a **Sportmonks Football API**. Ela busca os jogos do dia e, quando o plano/API fornecer previsões, exibe as probabilidades retornadas pela API. A Sportmonks documenta o endpoint de jogos por data e os recursos de participantes, estatísticas, odds e previsões. citeturn1search7turn1search1turn1search9

Sem uma chave configurada, o app continua abrindo em modo demonstração.

**Importante:** não coloque uma chave de produção dentro de um APK distribuído. Para produção, o ideal é usar um backend seu para guardar o token e entregar ao app apenas os dados necessários. O Android recomenda comunicação segura por HTTPS e requer a permissão `INTERNET` para operações de rede. citeturn0search3

## Configurar dados reais

1. Crie uma conta na Sportmonks e gere um token da Football API. A API fornece fixtures, estatísticas, escalações, xG, odds e previsões, dependendo do plano/add-ons. citeturn0search0turn1search11
2. Copie `local.properties.example` para `local.properties`.
3. Troque `COLOQUE_SUA_CHAVE_AQUI` pela sua chave.
4. Abra o projeto no Android Studio e sincronize o Gradle.
5. Execute o app. A tela inicial consultará os jogos da data atual.
6. Para previsões, a sua assinatura precisa disponibilizar o recurso de Predictions; a documentação informa que nem toda partida é considerada previsível. citeturn1search0turn1search9

## Como abrir

1. Instale o Android Studio.
2. Abra a pasta `PalpitePro`.
3. Aguarde o Gradle sincronizar.
4. Execute no emulador ou em um celular Android.
5. Para gerar APK: Build > Build APK(s).

O projeto usa Android Gradle Plugin 9.4.0 e Gradle 9.6.0, compatíveis com versões atuais do Android Studio.

## Próxima etapa recomendada

Adicionar:
- API de partidas/resultados
- API de odds
- banco de dados
- login
- notificações
- modelo estatístico real
- painel administrativo
- assinatura Premium

## Arquitetura do cálculo

Nesta versão, a fonte de previsão é a própria camada de Predictions quando disponível. A próxima evolução recomendada é adicionar um motor próprio: forma recente + força casa/fora + xG + finalizações + desfalques + odds implícitas, com calibração histórica e backtesting. Assim o app passa a separar claramente **probabilidade do modelo**, **probabilidade implícita da odd** e **valor esperado**.

Para odds, a Sportmonks documenta endpoints de pré-jogo e ao vivo; outra opção de fornecedor é a TheOddsAPI. citeturn0search2turn0search5


## Motor de palpites e escanteios

O MVP agora inclui `PredictionEngine`, que calcula linhas de escanteios usando uma distribuição de Poisson a partir da soma das médias de escanteios das equipes. A API Sportmonks identifica `corners` como o statistic type ID 34 e permite consultar estatísticas de equipes por temporada. citeturn0search1turn0search2

Mercados incluídos no app:
- Mais de 8,5 escanteios
- Mais de 9,5 escanteios
- Mais de 10,5 escanteios
- Média projetada de escanteios
- Confiança do modelo

A documentação também mostra que fixtures podem ser enriquecidos com estatísticas, e há exemplos de respostas de partidas com estatísticas e odds. citeturn0search10turn0search4

**Nota técnica:** o motor atual é um MVP transparente, não um modelo de machine learning validado. Antes de comercializar ou apresentar como previsão confiável, é necessário executar backtesting em uma base histórica, calibrar probabilidades e acompanhar métricas como Brier score, log loss, ROI e taxa de acerto por mercado.


## Evolução v4 — backtesting e calibração

A versão 4 adiciona:
- SQLite para registrar cada previsão antes do resultado;
- liquidação posterior das previsões;
- Brier Score;
- Log Loss;
- acurácia por limiar;
- métricas separadas por mercado;
- rotina de calibração por faixas de probabilidade;
- importador CSV para históricos externos;
- tela de Backtesting no perfil.

### Formato CSV histórico

`market,probability,outcome`

Exemplo:
`over_8_5_corners,0.63,1`

Use `outcome=1` quando o evento ocorreu e `0` quando não ocorreu.

### Arquitetura recomendada para produção

1. API de fixtures/estatísticas/odds.
2. Backend próprio para esconder tokens.
3. Pipeline histórico para gerar features.
4. Modelo por mercado (1X2, gols, BTTS, escanteios, cartões).
5. Split temporal treino/validação/teste.
6. Calibração somente no conjunto de validação.
7. Backtest fora da amostra.
8. Monitoramento contínuo de Brier, Log Loss, calibração e desempenho por mercado.

O código desta versão implementa a infraestrutura de avaliação; ele **não declara que o modelo já tem vantagem estatística ou retorno positivo**. Isso precisa ser demonstrado com um histórico real, sem look-ahead bias.
