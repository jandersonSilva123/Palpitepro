plugins {
    id("com.android.application")
}

android {
    buildFeatures { buildConfig = true }
    namespace = "br.com.palpitepro"
    compileSdk = 36

    defaultConfig {
        buildConfigField("String", "SPORTMONKS_TOKEN", "\"${project.findProperty("SPORTMONKS_TOKEN") ?: ""}\"")
        applicationId = "br.com.palpitepro"
        minSdk = 24
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
        debug {
            isDebuggable = true
        }
    }
}