package br.com.palpitepro;

import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class SportmonksApi {
    public interface Callback { void success(List<Match> matches); void error(String message); }

    public static class Match {
        public String league, home, away, homeProb, drawProb, awayProb;
        public long homeId, awayId, seasonId;
        public double homeCorners = -1, awayCorners = -1;

        public Match(String league, String home, String away, String hp, String dp, String ap,
                     long homeId, long awayId, long seasonId) {
            this.league=league; this.home=home; this.away=away;
            this.homeProb=hp; this.drawProb=dp; this.awayProb=ap;
            this.homeId=homeId; this.awayId=awayId; this.seasonId=seasonId;
        }
    }

    public static void today(Callback callback) {
        new Thread(() -> {
            try {
                String token = BuildConfig.SPORTMONKS_TOKEN;
                if (token == null || token.trim().isEmpty())
                    throw new Exception("Chave Sportmonks não configurada.");

                String date = LocalDate.now().toString();
                String endpoint = "https://api.sportmonks.com/v3/football/fixtures/date/" + date
                        + "?api_token=" + token + "&include=participants;league;predictions";

                JSONObject json = getJson(endpoint, token);
                JSONArray data = json.optJSONArray("data");
                List<Match> result = new ArrayList<>();

                if (data != null) {
                    for (int i=0; i<data.length() && result.size()<20; i++) {
                        JSONObject f=data.optJSONObject(i);
                        if(f==null) continue;

                        String league="";
                        JSONObject lg=f.optJSONObject("league");
                        if(lg!=null) league=lg.optString("name","");

                        JSONArray participants=f.optJSONArray("participants");
                        String home="", away="";
                        long homeId=-1, awayId=-1;
                        if(participants!=null) {
                            for(int j=0;j<participants.length();j++){
                                JSONObject p=participants.optJSONObject(j);
                                if(p==null) continue;
                                String name=p.optString("name","");
                                long id=p.optLong("id",-1);
                                JSONObject meta=p.optJSONObject("meta");
                                String loc=meta==null ? "" : meta.optString("location","");
                                if("home".equalsIgnoreCase(loc)){home=name; homeId=id;}
                                else if("away".equalsIgnoreCase(loc)){away=name; awayId=id;}
                            }
                            if(home.isEmpty() && participants.length()>0){
                                JSONObject p=participants.optJSONObject(0);
                                home=p.optString("name",""); homeId=p.optLong("id",-1);
                            }
                            if(away.isEmpty() && participants.length()>1){
                                JSONObject p=participants.optJSONObject(1);
                                away=p.optString("name",""); awayId=p.optLong("id",-1);
                            }
                        }

                        String hp="—",dp="—",ap="—";
                        JSONArray preds=f.optJSONArray("predictions");
                        if(preds!=null){
                            for(int j=0;j<preds.length();j++){
                                JSONObject p=preds.optJSONObject(j);
                                JSONObject vals=p==null?null:p.optJSONObject("predictions");
                                if(vals!=null && vals.has("home") && vals.has("draw") && vals.has("away")){
                                    hp=pct(vals.optDouble("home",-1));
                                    dp=pct(vals.optDouble("draw",-1));
                                    ap=pct(vals.optDouble("away",-1));
                                    break;
                                }
                            }
                        }

                        long seasonId=f.optLong("season_id",-1);
                        if(!home.isEmpty() && !away.isEmpty())
                            result.add(new Match(league,home,away,hp,dp,ap,homeId,awayId,seasonId));
                    }
                }

                // Enrich a limited number of matches with season corner averages.
                for (Match m : result) {
                    if (m.homeId > 0 && m.awayId > 0 && m.seasonId > 0) {
                        m.homeCorners = teamCornerAverage(m.homeId, m.seasonId, token);
                        m.awayCorners = teamCornerAverage(m.awayId, m.seasonId, token);
                    }
                }

                deliver(() -> callback.success(result));
            } catch(Exception e) {
                deliver(() -> callback.error(e.getMessage()==null ? "Erro desconhecido" : e.getMessage()));
            }
        }).start();
    }

    static double teamCornerAverage(long teamId, long seasonId, String token) {
        try {
            String url="https://api.sportmonks.com/v3/football/teams/"+teamId
                    +"?api_token="+token
                    +"&include=statistics.details.type"
                    +"&filters=teamStatisticSeasons:"+seasonId+";teamStatisticDetailTypes:34";
            JSONObject json=getJson(url,token);
            JSONObject team=json.optJSONObject("data");
            if(team==null) return -1;
            JSONArray stats=team.optJSONArray("statistics");
            if(stats==null) return -1;
            for(int i=0;i<stats.length();i++){
                JSONObject s=stats.optJSONObject(i);
                JSONArray details=s==null?null:s.optJSONArray("details");
                if(details==null) continue;
                for(int j=0;j<details.length();j++){
                    JSONObject d=details.optJSONObject(j);
                    if(d==null || d.optInt("type_id",-1)!=34) continue;
                    JSONObject value=d.optJSONObject("value");
                    if(value==null) continue;
                    double avg=value.optDouble("average",-1);
                    if(avg>=0) return avg;
                    JSONObject all=value.optJSONObject("all");
                    if(all!=null) return all.optDouble("average",-1);
                }
            }
        } catch(Exception ignored) {}
        return -1;
    }

    static JSONObject getJson(String endpoint, String token) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(endpoint).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(10000);
        c.setReadTimeout(15000);
        int code=c.getResponseCode();
        BufferedReader r=new BufferedReader(new InputStreamReader(
                code>=200&&code<300?c.getInputStream():c.getErrorStream()));
        StringBuilder body=new StringBuilder(); String line;
        while((line=r.readLine())!=null) body.append(line);
        r.close(); c.disconnect();
        if(code<200||code>=300) throw new Exception("API HTTP "+code);
        return new JSONObject(body.toString());
    }

    static String pct(double x) {
        return x<0 ? "—" : String.format(Locale.US,"%.0f%%",x);
    }
    static void deliver(Runnable r){new Handler(Looper.getMainLooper()).post(r);}
}