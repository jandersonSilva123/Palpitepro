package br.com.palpitepro;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class PredictionDb extends SQLiteOpenHelper {
    public PredictionDb(Context c){super(c,"palpitepro.db",null,1);}
    @Override public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE predictions("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT,"+
                "fixture_id INTEGER,"+
                "home TEXT, away TEXT,"+
                "market TEXT,"+
                "prob REAL,"+
                "line REAL,"+
                "created_at INTEGER,"+
                "actual REAL,"+
                "settled INTEGER DEFAULT 0)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldV,int newV){}
    public long add(long fixtureId,String home,String away,String market,double prob,double line){
        ContentValues v=new ContentValues();
        v.put("fixture_id",fixtureId);v.put("home",home);v.put("away",away);
        v.put("market",market);v.put("prob",prob);v.put("line",line);
        v.put("created_at",System.currentTimeMillis());v.put("settled",0);
        return getWritableDatabase().insert("predictions",null,v);
    }
    public void settle(long id,double actual){
        ContentValues v=new ContentValues();v.put("actual",actual);v.put("settled",1);
        getWritableDatabase().update("predictions",v,"id=?",new String[]{String.valueOf(id)});
    }
    public Cursor settled(){return getReadableDatabase().rawQuery(
        "SELECT market,prob,actual FROM predictions WHERE settled=1 ORDER BY created_at",null);}
}