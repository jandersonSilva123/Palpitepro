package br.com.palpitepro;

import android.database.Cursor;
import java.util.HashMap;
import java.util.Map;

public class BacktestMetrics {
    public static class Report {
        public int n;
        public double brier, logLoss, accuracy;
        public Map<String,Integer> samples=new HashMap<>();
        public Map<String,Double> brierByMarket=new HashMap<>();
    }

    public static Report from(Cursor c){
        Report r=new Report();
        while(c.moveToNext()){
            String market=c.getString(0);
            double p=Math.max(.0001,Math.min(.9999,c.getDouble(1)));
            double actual=c.getDouble(2); // 1 if event occurred, 0 otherwise
            double b=(p-actual)*(p-actual);
            double ll=-(actual*Math.log(p)+(1-actual)*Math.log(1-p));
            r.n++; r.brier+=b; r.logLoss+=ll;
            if((p>=.5)==(actual>=.5)) r.accuracy++;
            r.samples.put(market,r.samples.containsKey(market)?r.samples.get(market)+1:1);
            r.brierByMarket.put(market,
                r.brierByMarket.containsKey(market)?r.brierByMarket.get(market)+b:b);
        }
        if(r.n>0){r.brier/=r.n;r.logLoss/=r.n;r.accuracy/=r.n;}
        for(String k:r.brierByMarket.keySet())
            r.brierByMarket.put(k,r.brierByMarket.get(k)/r.samples.get(k));
        return r;
    }
}