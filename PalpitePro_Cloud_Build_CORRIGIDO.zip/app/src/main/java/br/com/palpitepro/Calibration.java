package br.com.palpitepro;

public class Calibration {
    // Isotonic-like bin calibration for the MVP.
    // Feed historical (prediction, outcome) pairs; returns empirical probability.
    public static double calibrated(double p, double[] probs, double[] outcomes){
        if(probs==null||outcomes==null||probs.length==0||probs.length!=outcomes.length) return p;
        double width=.10;
        double lo=Math.max(0,Math.floor(p/width)*width);
        double hi=Math.min(1,lo+width);
        double sum=0;int n=0;
        for(int i=0;i<probs.length;i++){
            if(probs[i]>=lo && (probs[i]<hi || (hi>=1 && probs[i]<=hi))){
                sum+=outcomes[i];n++;
            }
        }
        if(n<10) return p; // don't overfit tiny samples
        return Math.max(.01,Math.min(.99,sum/n));
    }
}