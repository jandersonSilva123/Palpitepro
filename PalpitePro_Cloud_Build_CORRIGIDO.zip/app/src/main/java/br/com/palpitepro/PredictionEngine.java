package br.com.palpitepro;

import java.util.Locale;

public class PredictionEngine {
    public static class Result {
        public double over15, btts, over85Corners, over95Corners, over105Corners;
        public double expectedCorners, confidence;
        public String cornerSummary;
    }

    // Lightweight, transparent model for the MVP.
    // Production version should be trained/calibrated with historical fixtures.
    public static Result analyze(SportmonksApi.Match m) {
        Result r=new Result();

        double hc=m.homeCorners>0?m.homeCorners:5.2;
        double ac=m.awayCorners>0?m.awayCorners:4.7;
        r.expectedCorners=Math.max(0.5, hc+ac);

        r.over85Corners=poissonOver(r.expectedCorners,8.5);
        r.over95Corners=poissonOver(r.expectedCorners,9.5);
        r.over105Corners=poissonOver(r.expectedCorners,10.5);

        // Conservative demonstration estimates until xG/goal history is connected.
        r.over15=0.70;
        r.btts=0.55;

        double dataQuality=(m.homeCorners>0&&m.awayCorners>0)?1.0:0.55;
        r.confidence=Math.min(9.0, 5.5 + 2.0*dataQuality
                + Math.min(1.0, Math.abs(r.expectedCorners-9.0)/3.0));

        r.cornerSummary=String.format(Locale.US,
                "Média projetada: %.1f escanteios | Casa %.1f + Fora %.1f",
                r.expectedCorners,hc,ac);
        return r;
    }

    static double poissonOver(double lambda,double line){
        // P(X >= ceil(line)) for a Poisson variable.
        int k=(int)Math.floor(line)+1;
        double p=Math.exp(-lambda);
        double cumulative=p;
        for(int i=1;i<k;i++){p*=lambda/i; cumulative+=p;}
        return Math.max(0,Math.min(1,1-cumulative));
    }

    public static String pct(double p){return String.format(Locale.US,"%.0f%%",p*100);}
}