package br.com.palpitepro;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout content;
    private PredictionDb predictionDb;

    private int bg, surface, surface2, green, white, muted, yellow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadColors();
        predictionDb = new PredictionDb(this);
        buildShell();
        showTips();
    }

    private void loadColors() {
        bg = Color.rgb(6, 16, 20);
        surface = Color.rgb(11, 26, 32);
        surface2 = Color.rgb(16, 37, 45);
        green = Color.rgb(24, 231, 122);
        white = Color.rgb(244, 248, 249);
        muted = Color.rgb(143, 163, 170);
        yellow = Color.rgb(255, 201, 74);
    }

    private void buildShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(18), dp(16), dp(18));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(8), dp(8), dp(8), dp(8));
        nav.setBackgroundColor(surface);

        addNav(nav, "Palpites", v -> showTips());
        addNav(nav, "Backtest", v -> showBacktest());
        addNav(nav, "Stats", v -> showStats());
        addNav(nav, "Perfil", v -> showProfile());

        root.addView(nav, new LinearLayout.LayoutParams(-1, dp(62)));
        setContentView(root);
    }

    private void addNav(LinearLayout nav, String text, View.OnClickListener listener) {
        TextView b = tv(text, 12, white);
        b.setGravity(Gravity.CENTER);
        b.setOnClickListener(listener);
        nav.addView(b, new LinearLayout.LayoutParams(0, dp(46), 1));
    }

    private void base(String title, String subtitle) {
        content.removeAllViews();

        TextView t = tv(title, 28, white);
        t.setTypeface(null, 1);
        content.addView(t);

        TextView s = tv(subtitle, 14, muted);
        content.addView(s, margin(0, 4, 0, 16));
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(16), dp(16), dp(16));
        c.setBackground(rounded(surface, 18));
        return c;
    }

    private TextView label(String text) {
        TextView v = tv(text, 12, green);
        v.setTypeface(null, 1);
        v.setLetterSpacing(.08f);
        v.setPadding(0, 0, 0, dp(10));
        return v;
    }

    private TextView tv(String text, float size, int color) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(color);
        return v;
    }

    private TextView button(String text) {
        TextView b = tv(text, 15, bg);
        b.setGravity(Gravity.CENTER);
        b.setTypeface(null, 1);
        b.setPadding(dp(16), dp(12), dp(16), dp(12));
        b.setBackground(rounded(green, 14));
        return b;
    }

    private void addMarket(LinearLayout parent, String market, String probability,
                           String confidence, int confidenceColor) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(0, dp(10), 0, dp(10));

        TextView m = tv(market, 15, white);
        row.addView(m);

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.HORIZONTAL);
        TextView p = tv(probability, 20, green);
        p.setTypeface(null, 1);
        TextView c = tv("  " + confidence, 12, confidenceColor);
        c.setGravity(Gravity.CENTER_VERTICAL);
        info.addView(p);
        info.addView(c);
        row.addView(info);
        parent.addView(row);
    }

    private GradientDrawable rounded(int color, float radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private LinearLayout.LayoutParams margin() {
        return margin(0, 0, 0, 12);
    }

    private LinearLayout.LayoutParams margin(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + .5f);
    }

    private void showTips() {
        base("Palpites", "Seleção de mercados com maior probabilidade estimada");

        LinearLayout c = card();
        c.addView(label("🔥 DESTAQUES"));
        addMarket(c, "Flamengo x Palmeiras • Mais de 1,5 gols", "70%", "ALTA", green);
        addMarket(c, "Real Madrid x Man. City • Ambas marcam", "55%", "MÉDIA", yellow);
        addMarket(c, "Mercado de escanteios • +8,5", "60%", "ALTA", green);
        addMarket(c, "Mercado de escanteios • +9,5", "52%", "MÉDIA", yellow);
        content.addView(c, margin());

        LinearLayout how = card();
        how.addView(label("COMO O MODELO FUNCIONA"));
        how.addView(tv("• Usa médias de escanteios por equipe e temporada quando disponíveis.", 14, white));
        how.addView(tv("• Calcula linhas de escanteios com distribuição de Poisson.", 14, white));
        how.addView(tv("• Separa probabilidade do modelo de odds de mercado.", 14, white));
        how.addView(tv("• O backtesting deve ser feito antes de usar o modelo em produção.", 14, white));
        content.addView(how, margin());

        TextView info = button("🔄  Atualizar jogos");
        info.setOnClickListener(v -> showDemoMessage());
        content.addView(info, margin());
    }

    private void showDemoMessage() {
        content.addView(tv("Modo demonstração: configure a chave Sportmonks para carregar jogos reais.", 13, muted),
                margin());
    }

    private void showBacktest() {
        base("Backtesting", "Desempenho histórico do modelo");

        LinearLayout c = card();
        c.addView(label("MÉTRICAS"));
        android.database.Cursor cur = predictionDb.settled();
        BacktestMetrics.Report r = BacktestMetrics.from(cur);
        cur.close();

        c.addView(tv("Amostras: " + r.n, 16, white));
        c.addView(tv(String.format(Locale.US, "Brier Score: %.4f", r.brier), 16, green));
        c.addView(tv(String.format(Locale.US, "Log Loss: %.4f", r.logLoss), 16, green));
        c.addView(tv(String.format(Locale.US, "Acurácia (limiar 50%%): %.1f%%", r.accuracy * 100), 16, white));
        content.addView(c, margin());

        LinearLayout d = card();
        d.addView(label("COMO INTERPRETAR"));
        d.addView(tv("Brier e Log Loss medem a qualidade das probabilidades; menor é melhor.", 13, muted));
        d.addView(tv("Antes de publicar o modelo, separe treino, validação e teste por data.", 13, muted));
        content.addView(d, margin());
    }

    private void showStats() {
        base("Estatísticas", "Indicadores de desempenho");

        LinearLayout c = card();
        c.addView(label("BRASILEIRÃO"));
        c.addView(tv("Média de gols", 14, muted));
        c.addView(tv("2,48 gols / jogo", 24, green));
        c.addView(tv("Mais de 2,5: 52%", 14, white));
        c.addView(tv("Escanteios: 10,1 / jogo", 14, white));
        c.addView(tv("Cartões: 4,7 / jogo", 14, white));
        content.addView(c, margin());

        LinearLayout d = card();
        d.addView(label("FILTROS"));
        String[] chips = {"Hoje", "Mais de 1,5", "Ambas marcam", "Escanteios", "Cartões", "Odds"};
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        for (String s : chips) {
            TextView x = tv(s, 11, white);
            x.setGravity(Gravity.CENTER);
            x.setBackground(rounded(surface2, 24));
            x.setPadding(dp(12), dp(8), dp(12), dp(8));
            r.addView(x, new LinearLayout.LayoutParams(-2, dp(38)));
        }
        d.addView(r);
        content.addView(d, margin());
    }

    private void showProfile() {
        base("Meu perfil", "PalpitePro");

        LinearLayout c = card();
        TextView name = tv("Janderson Silva", 20, white);
        name.setTypeface(null, 1);
        c.addView(name);
        c.addView(tv("Membro desde 2026", 13, muted));
        content.addView(c, margin());

        TextView premium = button("💎  Conhecer o Premium");
        content.addView(premium, margin());

        LinearLayout menu = card();
        String[] items = {"Meus palpites", "Meus favoritos", "Alertas",
                "Backtesting do modelo", "Histórico de resultados",
                "Configurações", "Ajuda e suporte"};
        for (String s : items) {
            TextView x = tv("›  " + s, 15, white);
            x.setPadding(0, dp(12), 0, dp(12));
            if (s.startsWith("Backtesting")) {
                x.setOnClickListener(v -> showBacktest());
            }
            menu.addView(x);
        }
        content.addView(menu, margin());
    }

    @Override
    protected void onDestroy() {
        if (predictionDb != null) predictionDb.close();
        super.onDestroy();
    }
}
